// background.js — Service worker for dassistant Chrome extension
// Handles: tab capture, backend communication, email-based accounts

const BACKEND_URL = "https://godsfavor.onrender.com";

// ---------------------------------------------------------------------------
// Account management (email-based)
// ---------------------------------------------------------------------------

async function getEmail() {
  const result = await chrome.storage.local.get("email");
  return result.email || null;
}

async function setEmail(email) {
  await chrome.storage.local.set({ email });
}

async function getLicenseKey() {
  const result = await chrome.storage.local.get("licenseKey");
  return result.licenseKey || null;
}

async function setLicenseKey(key) {
  await chrome.storage.local.set({ licenseKey: key });
}

async function ensureAccount() {
  // If we already have a license key, return it.
  let key = await getLicenseKey();
  if (key) return key;

  // No license key — need an email to register.
  const email = await getEmail();
  if (!email) return null;

  // Register or login with the email.
  try {
    const resp = await fetch(`${BACKEND_URL}/account/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    if (!resp.ok) return null;
    const data = await resp.json();
    if (data.license_key) {
      await setLicenseKey(data.license_key);
      return data.license_key;
    }
  } catch (e) {
    console.error("Account registration failed:", e);
  }
  return null;
}

// ---------------------------------------------------------------------------
// Backend analysis
// ---------------------------------------------------------------------------

async function analyzeContent(mediaBase64, mimeType, licenseKey) {
  // No assessment hint — Gemini auto-detects what's on screen
  // (MCQ, verification list, gesture, or general content).
  const payload = {
    media_base64: mediaBase64,
    mime_type: mimeType,
    assessment_hint: null,
  };

  const headers = { "Content-Type": "application/json" };
  if (licenseKey) headers["X-License-Key"] = licenseKey;

  // Use AbortController to set a 25-second timeout. Render's free tier
  // kills requests after 30s, so we abort at 25s to give a clean error
  // instead of a mysterious hang.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 25000);

  let resp;
  try {
    resp = await fetch(`${BACKEND_URL}/analyze`, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
  } catch (e) {
    clearTimeout(timeoutId);
    // Network error — server unreachable, DNS failure, timeout, etc.
    return { error: true, code: "NETWORK_ERROR", message: "We couldn't reach our servers. Please check your internet connection and try again." };
  }
  clearTimeout(timeoutId);

  if (resp.status === 402) {
    return { error: true, code: "NO_CREDITS", message: "You're out of credits. Visit the website to add more and continue analyzing." };
  }

  if (resp.status === 503) {
    return { error: true, code: "AI_BUSY", message: "Our AI is experiencing high demand right now. Please try again in a moment." };
  }

  if (resp.status === 401 || resp.status === 404) {
    return { error: true, code: "NO_ACCOUNT", message: "We couldn't verify your account. Click the extension icon to sign in again." };
  }

  if (resp.status === 403) {
    return { error: true, code: "BLOCKED", message: "Your account has been suspended. Please contact support for assistance." };
  }

  if (resp.status === 422) {
    return { error: true, code: "BAD_REQUEST", message: "We couldn't process your recording. Please try analyzing again." };
  }

  if (!resp.ok) {
    // Don't leak raw server text or status codes to the customer.
    return { error: true, code: "SERVER_ERROR", message: "Something went wrong on our end. Please try again in a moment." };
  }

  return await resp.json();
}

// ---------------------------------------------------------------------------
// Video clip capture — records a short clip from the active tab.
// Uses chrome.tabCapture + offscreen document (MV3 requires offscreen
// for DOM/video APIs).
// ---------------------------------------------------------------------------

let recordingInProgress = false;

async function ensureOffscreenDocument() {
  // Check if one already exists.
  const existing = await chrome.offscreen.hasDocument();
  if (existing) return;

  await chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["USER_MEDIA", "DISPLAY_MEDIA"],
    justification: "Recording tab capture stream for video analysis.",
  });
}

async function captureVideoClip(durationMs = 5000) {
  if (recordingInProgress) return null;
  recordingInProgress = true;

  try {
    // Get the active tab.
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return null;

    // Get a tab capture stream ID.
    const streamId = await new Promise((resolve) => {
      chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id }, (id) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(id);
        }
      });
    });

    if (!streamId) return null;

    // Ensure offscreen document exists.
    await ensureOffscreenDocument();

    // Tell the offscreen document to start recording.
    const recordResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        { type: "START_RECORDING", streamId, durationMs },
        (resp) => {
          if (chrome.runtime.lastError) {
            resolve({ success: false, error: chrome.runtime.lastError.message });
          } else {
            resolve(resp);
          }
        }
      );
    });

    if (!recordResult || !recordResult.success) {
      return null;
    }

    // Get the recorded data.
    const dataResult = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_RECORDED_DATA" }, (resp) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(resp);
        }
      });
    });

    if (!dataResult || !dataResult.success || !dataResult.chunks || dataResult.chunks.length === 0) {
      return null;
    }

    // Convert chunks to a single ArrayBuffer for sending to backend.
    // The chunks are Blob objects in the offscreen context — but they
    // get serialized as ArrayBuffer when sent via messaging.
    // Instead, let's read them as base64 from the offscreen document.
    // Actually, we need to fetch the blob from the offscreen document.
    // The simplest approach: send the blob URL back and fetch it.

    // Re-request with a different approach — ask offscreen to give us
    // the base64 data directly.
    const base64Result = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "GET_RECORDED_BASE64" }, (resp) => {
        if (chrome.runtime.lastError) {
          resolve(null);
        } else {
          resolve(resp);
        }
      });
    });

    if (!base64Result || !base64Result.success) return null;

    return {
      base64: base64Result.base64,
      mimeType: base64Result.mimeType || "video/webm",
    };
  } catch (e) {
    console.error("Video capture failed:", e);
    return null;
  } finally {
    recordingInProgress = false;
  }
}

// Fallback: capture a single screenshot (used if video fails).
async function captureScreenshot() {
  return new Promise((resolve) => {
    chrome.tabs.captureVisibleTab(null, { format: "jpeg", quality: 85 }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        resolve(null);
      } else {
        resolve(dataUrl);
      }
    });
  });
}

// ---------------------------------------------------------------------------
// Payment flow: Users visit the website to purchase credits.
// Extension never handles payment directly (Chrome MV3 + security best practice).
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// Mode management
// ---------------------------------------------------------------------------

async function getMode() {
  const result = await chrome.storage.local.get("mode");
  return result.mode || "MULTIPLE_CHOICE";
}

async function toggleMode() {
  const current = await getMode();
  const next = current === "MULTIPLE_CHOICE" ? "PHYSICAL_GESTURE" : "MULTIPLE_CHOICE";
  await chrome.storage.local.set({ mode: next });
  return next;
}

// ---------------------------------------------------------------------------
// Message handler
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "ANALYZE": {
        const licenseKey = await getLicenseKey();
        if (!licenseKey) {
          sendResponse({ error: true, code: "NO_ACCOUNT", message: "No account. Click the extension icon to sign in with your email." });
          return;
        }

        // Notify content script that recording is starting.
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]) {
            chrome.tabs.sendMessage(tabs[0].id, { type: "RECORDING_STARTED" }, () => {
              if (chrome.runtime.lastError) { /* ignore */ }
            });
          }
        });

        const clip = await captureVideoClip(5000);

        if (clip && clip.base64) {
          // Send video to backend — Gemini auto-detects the mode.
          const result = await analyzeContent(clip.base64, clip.mimeType, licenseKey);
          sendResponse(result);
          return;
        }

        // Video capture failed — fall back to screenshot.
        const screenshotDataUrl = await captureScreenshot();
        if (!screenshotDataUrl) {
          sendResponse({ error: true, code: "CAPTURE_FAILED", message: "We couldn't capture your screen. Please try again, and make sure you're on a regular web page (not a Chrome settings page)." });
          return;
        }

        const base64 = screenshotDataUrl.split(",")[1];
        const result = await analyzeContent(base64, "image/jpeg", licenseKey);
        sendResponse(result);
        return;
      }



      case "TOGGLE_MODE": {
        const newMode = await toggleMode();
        sendResponse({ mode: newMode });
        return;
      }

      case "GET_STATUS": {
        const email = await getEmail();
        const licenseKey = await getLicenseKey();
        const mode = await getMode();
        sendResponse({ email, licenseKey, mode });
        return;
      }

      case "REGISTER_EMAIL": {
        await setEmail(msg.email);
        const key = await ensureAccount();
        sendResponse({ licenseKey: key, email: msg.email });
        return;
      }

      case "LOGIN_EMAIL": {
        // /account/register is an upsert — it returns the existing key
        // if the email already exists, or creates a new account with 15
        // trial credits (5 free analyses) if it doesn't. Calling it
        // directly avoids a redundant login round-trip.
        try {
          const resp = await fetch(`${BACKEND_URL}/account/register`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ email: msg.email }),
          });
          if (resp.ok) {
            const data = await resp.json();
            if (data.license_key) {
              await setEmail(msg.email);
              await setLicenseKey(data.license_key);
              sendResponse({ licenseKey: data.license_key, email: msg.email, credits: data.credits });
              return;
            }
          }
          sendResponse({ error: true, message: "We couldn't connect to our servers. Please check your internet connection and try again." });
        } catch (e) {
          sendResponse({ error: true, message: "We couldn't sign you in right now. Please check your internet connection and try again." });
        }
        return;
      }

      case "SHOW_OVERLAY_ON_TAB": {
        // Popup asked us to show the overlay on the active tab.
        // We handle this in the service worker because the popup
        // closes immediately after sending the message.
        try {
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tab) return;
          const tabId = tab.id;

          // Can't inject on chrome:// pages, edge://, etc.
          if (tab.url && (tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("chrome-extension://"))) {
            return;
          }

          // Try sending the message first (content script already loaded).
          let sent = false;
          try {
            await new Promise((resolve) => {
              chrome.tabs.sendMessage(tabId, { type: "SHOW_OVERLAY_ONLY" }, (resp) => {
                if (chrome.runtime.lastError) {
                  resolve(null);
                } else {
                  sent = true;
                  resolve(resp);
                }
              });
            });
          } catch (e) {}

          if (sent) return;

          // Content script not loaded — inject CSS + JS, then send.
          try {
            await chrome.scripting.insertCSS({
              target: { tabId },
              files: ["overlay.css"]
            });
            await chrome.scripting.executeScript({
              target: { tabId },
              files: ["content.js"]
            });
            // Wait a brief moment for the content script to finish
            // initializing (createOverlay runs at the bottom of the
            // file and needs a tick to complete).
            await new Promise(resolve => setTimeout(resolve, 200));
            // Now send the message to force-show the overlay.
            chrome.tabs.sendMessage(tabId, { type: "SHOW_OVERLAY_ONLY" }, () => {
              if (chrome.runtime.lastError) { /* can't inject on this page */ }
            });
          } catch (e) {
            // Can't inject on chrome:// pages etc.
          }
        } catch (e) {}
        return;
      }

      default:
        sendResponse({ error: true, message: "Unknown message type" });
    }
  })();
  return true;
});

// ---------------------------------------------------------------------------
// Keyboard shortcuts
// ---------------------------------------------------------------------------

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "analyze") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: "SHOW_OVERLAY_TRIGGER" }, () => {
        if (chrome.runtime.lastError) {
          // Content script not loaded on this page (e.g. chrome:// pages).
          console.debug("Cannot trigger overlay on this page:", chrome.runtime.lastError.message);
        }
      });
    }
  } else if (command === "toggle-mode") {
    const newMode = await toggleMode();
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      chrome.tabs.sendMessage(tab.id, { type: "MODE_CHANGED", mode: newMode }, () => {
        if (chrome.runtime.lastError) {
          console.debug("Cannot update mode on this page:", chrome.runtime.lastError.message);
        }
      });
    }
  }
});

// ---------------------------------------------------------------------------
// On first install — no auto-popup (MV3 requires user gesture).
// The user will click the extension icon naturally.
// ---------------------------------------------------------------------------

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    console.log("dassistant installed — user should click the icon to sign in.");
  }
});
