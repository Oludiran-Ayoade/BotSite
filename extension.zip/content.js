// content.js — Injects overlay into the page and handles analysis flow
//
// Wrapped in an IIFE to avoid "SyntaxError: redeclaration of let/const"
// when chrome.scripting.executeScript re-injects this file after an
// extension reload. The IIFE creates a fresh scope each time, so the
// let/const declarations don't conflict with the previous injection.
// The message listener and observer are cleaned up before re-adding
// (see window.__dassistantListener and window.__dassistantObserver).
(function () {
  // ---------------------------------------------------------------------------
  // Overlay DOM
  // ---------------------------------------------------------------------------

  let overlayEl = null;
  let pillEl = null;
  let pillTextEl = null;
  let pillCreditEl = null;
  let panelEl = null;
  let indicatorEl = null;
  let headerEl = null;
  let subEl = null;
  let answersEl = null;
  let badgeEl = null;
  let spinnerEl = null;
  let modeEl = null;
  let creditEl = null;
  let minimizeEl = null;
  let closeEl = null;
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  let hiddenForCapture = false;
  let isAnalyzing = false;
  let dragStartX = 0;
  let dragStartY = 0;
  let didDragMove = false;
  const DRAG_THRESHOLD = 5; // px — below this, treat as click

  function createOverlay() {
    // If we already have a reference and it's still in the DOM, reuse it.
    if (overlayEl && document.body.contains(overlayEl)) {
      overlayEl.style.display = "block";
      overlayEl.style.visibility = "visible";
      return;
    }
    // Check if an overlay element exists in the DOM from a previous
    // injection (e.g. extension was reloaded). Reuse it instead of
    // creating a duplicate.
    const existing = document.getElementById("dassistant-overlay");
    if (existing && document.body.contains(existing)) {
      overlayEl = existing;
      // Re-bind all element references since our variables are fresh.
      pillEl = overlayEl.querySelector("#dassistant-pill");
      pillTextEl = overlayEl.querySelector("#dassistant-pill-text");
      pillCreditEl = overlayEl.querySelector("#dassistant-pill-credit");
      panelEl = overlayEl.querySelector("#dassistant-panel");
      indicatorEl = overlayEl.querySelector("#dassistant-indicator");
      headerEl = overlayEl.querySelector("#dassistant-header");
      subEl = overlayEl.querySelector("#dassistant-sub");
      answersEl = overlayEl.querySelector("#dassistant-answers");
      badgeEl = overlayEl.querySelector("#dassistant-badge");
      spinnerEl = overlayEl.querySelector("#dassistant-spinner");
      modeEl = overlayEl.querySelector("#dassistant-mode");
      creditEl = overlayEl.querySelector("#dassistant-credit");
      minimizeEl = overlayEl.querySelector("#dassistant-minimize");
      closeEl = overlayEl.querySelector("#dassistant-close");
      overlayEl.style.display = "block";
      overlayEl.style.visibility = "visible";
      return;
    }
    overlayEl = null; // stale reference — clear it.

    overlayEl = document.createElement("div");
    overlayEl.id = "dassistant-overlay";
    overlayEl.className = "dassistant-collapsed";
    overlayEl.style.display = "block";
    overlayEl.style.visibility = "visible";
    overlayEl.innerHTML = `
      <div id="dassistant-pill">
        <span id="dassistant-drag-handle" title="Drag to move">⠿</span>
        <span id="dassistant-pill-icon">✦</span>
        <span id="dassistant-pill-text">Analyze</span>
        <span id="dassistant-pill-credit"></span>
      </div>
      <div id="dassistant-panel">
        <div id="dassistant-header-bar">
          <span id="dassistant-drag-handle-panel" title="Drag to move">⠿</span>
          <span id="dassistant-indicator">●</span>
          <span id="dassistant-header">Ready</span>
          <span id="dassistant-mode">AUTO</span>
          <span id="dassistant-credit"></span>
          <span id="dassistant-minimize" title="Minimize">–</span>
          <span id="dassistant-close" title="Close">×</span>
        </div>
        <div id="dassistant-sub">Click the button or press Ctrl+Shift+U to analyze</div>
        <div id="dassistant-spinner" style="display:none;">
          <div class="dassistant-spin"></div>
        </div>
        <div id="dassistant-answers"></div>
        <div id="dassistant-badge"></div>
        <button id="dassistant-analyze-btn">Analyze Screen</button>
      </div>
    `;
    document.body.appendChild(overlayEl);

    pillEl = overlayEl.querySelector("#dassistant-pill");
    pillTextEl = overlayEl.querySelector("#dassistant-pill-text");
    pillCreditEl = overlayEl.querySelector("#dassistant-pill-credit");
    panelEl = overlayEl.querySelector("#dassistant-panel");
    indicatorEl = overlayEl.querySelector("#dassistant-indicator");
    headerEl = overlayEl.querySelector("#dassistant-header");
    subEl = overlayEl.querySelector("#dassistant-sub");
    answersEl = overlayEl.querySelector("#dassistant-answers");
    badgeEl = overlayEl.querySelector("#dassistant-badge");
    spinnerEl = overlayEl.querySelector("#dassistant-spinner");
    modeEl = overlayEl.querySelector("#dassistant-mode");
    creditEl = overlayEl.querySelector("#dassistant-credit");
    minimizeEl = overlayEl.querySelector("#dassistant-minimize");
    closeEl = overlayEl.querySelector("#dassistant-close");

    const analyzeBtn = overlayEl.querySelector("#dassistant-analyze-btn");
    analyzeBtn.addEventListener("click", triggerAnalyze);

    // Pill click — expand and run analysis immediately.
    // BUT: if the user was dragging the pill, suppress the click so
    // moving the overlay doesn't accidentally trigger an analysis.
    pillEl.addEventListener("click", (e) => {
      if (didDragMove) {
        didDragMove = false;
        return; // swallow click — it was a drag, not a tap
      }
      triggerAnalyze();
    });

    minimizeEl.addEventListener("click", (e) => {
      e.stopPropagation();
      collapseOverlay();
    });

    closeEl.addEventListener("click", (e) => {
      e.stopPropagation();
      hideOverlay();
    });

    // Mode toggle removed — we use auto-detect now.
    // The mode element is kept in the DOM for visual consistency
    // but is no longer clickable.

    // Dragging — only starts from the dedicated drag handle (⠿ icon),
    // not from the pill body or button. This cleanly separates "move"
    // from "click to analyze" so the two never conflict.
    const dragHandle = overlayEl.querySelector("#dassistant-drag-handle");
    const dragHandlePanel = overlayEl.querySelector("#dassistant-drag-handle-panel");
    // stopPropagation prevents the mousedown from bubbling to the pill
    // click handler, which would trigger an unwanted analysis.
    dragHandle.addEventListener("mousedown", (e) => { e.stopPropagation(); startDrag(e); });
    dragHandlePanel.addEventListener("mousedown", (e) => { e.stopPropagation(); startDrag(e); });
    document.addEventListener("mousemove", onDrag);
    document.addEventListener("mouseup", stopDrag);

    // Restore position — clamp to viewport so the overlay doesn't
    // appear off-screen if the window was resized since last drag.
    const saved = localStorage.getItem("dassistant-pos");
    if (saved) {
      try {
        const pos = JSON.parse(saved);
        const w = window.innerWidth;
        const h = window.innerHeight;
        const x = Math.max(0, Math.min(pos.x, w - 120));
        const y = Math.max(0, Math.min(pos.y, h - 40));
        overlayEl.style.left = x + "px";
        overlayEl.style.top = y + "px";
        overlayEl.style.right = "auto";
      } catch (e) {}
    }

    // Load mode + credit status.
    chrome.runtime.sendMessage({ type: "GET_STATUS" }, (resp) => {
      if (chrome.runtime.lastError) return;
      if (resp) {
        updateModeDisplay(resp.mode);
        if (resp.licenseKey) {
          creditEl.textContent = "✓ Active";
        }
      }
    });
  }

  function showOverlay() {
    createOverlay();
    overlayEl.style.display = "block";
    overlayEl.style.visibility = "visible";
  }

  function hideOverlay() {
    if (overlayEl) overlayEl.style.display = "none";
  }

  function expandOverlay() {
    createOverlay();
    overlayEl.style.display = "block";
    overlayEl.classList.remove("dassistant-collapsed");
    overlayEl.classList.add("dassistant-expanded");
  }

  function collapseOverlay() {
    if (!overlayEl) return;
    overlayEl.classList.remove("dassistant-expanded");
    overlayEl.classList.add("dassistant-collapsed");
    overlayEl.classList.remove("dassistant-pill-busy");
  }

  // ---------------------------------------------------------------------------
  // Dragging (works whether collapsed or expanded)
  // ---------------------------------------------------------------------------

  function startDrag(e) {
    // Drag only starts from the drag handle — no need to exclude other
    // elements since only the handle has this listener.
    isDragging = true;
    didDragMove = false;
    dragStartX = e.clientX;
    dragStartY = e.clientY;
    const rect = overlayEl.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;
    e.preventDefault();
  }

  function onDrag(e) {
    if (!isDragging) return;
    // Mark as a real drag only once the mouse moves beyond the
    // threshold — this distinguishes a click from a drag.
    if (!didDragMove) {
      const dx = Math.abs(e.clientX - dragStartX);
      const dy = Math.abs(e.clientY - dragStartY);
      if (dx > DRAG_THRESHOLD || dy > DRAG_THRESHOLD) {
        didDragMove = true;
      }
    }
    let x = e.clientX - dragOffsetX;
    let y = e.clientY - dragOffsetY;
    // Clamp to viewport so the overlay can't be dragged off-screen
    // and become unreachable.
    const w = window.innerWidth;
    const h = window.innerHeight;
    const rect = overlayEl.getBoundingClientRect();
    const ow = rect.width || 120;
    const oh = rect.height || 40;
    x = Math.max(0, Math.min(x, w - ow));
    y = Math.max(0, Math.min(y, h - oh));
    overlayEl.style.left = x + "px";
    overlayEl.style.top = y + "px";
    overlayEl.style.right = "auto";
  }

  function stopDrag() {
    if (!isDragging) return;
    isDragging = false;
    const rect = overlayEl.getBoundingClientRect();
    localStorage.setItem("dassistant-pos", JSON.stringify({ x: rect.left, y: rect.top }));
    // Keep didDragMove true so the subsequent click event is swallowed.
    // It will be reset on the next mousedown (startDrag) or the click
    // handler itself.
  }

  // ---------------------------------------------------------------------------
  // Display helpers
  // ---------------------------------------------------------------------------

  function updateModeDisplay(mode) {
    // Auto-detect mode — no longer show a mode label.
    // Kept for backwards compatibility if MODE_CHANGED messages arrive.
    modeEl.textContent = "AUTO";
  }

  function showLoading(text) {
    expandOverlay();
    overlayEl.classList.add("dassistant-pill-busy");
    pillTextEl.textContent = text || "Analyzing...";
    spinnerEl.style.display = "flex";
    indicatorEl.textContent = "●";
    indicatorEl.style.color = "#10b981";
    headerEl.textContent = text || "Analyzing...";
    subEl.textContent = "";
    answersEl.innerHTML = "";
    badgeEl.innerHTML = "";
    overlayEl.querySelector("#dassistant-analyze-btn").disabled = true;
  }

  function showResult(data) {
    expandOverlay();
    overlayEl.classList.remove("dassistant-pill-busy");
    pillTextEl.textContent = "Analyze";
    spinnerEl.style.display = "none";
    overlayEl.querySelector("#dassistant-analyze-btn").disabled = false;

    indicatorEl.textContent = "✓";
    indicatorEl.style.color = "#4ade80";
    headerEl.textContent = data.summary || "Analysis Complete";

    // Answers — Gemini returns objects with {number, statement, option, explanation, failure_reasons}.
    answersEl.innerHTML = "";
    if (data.answers && data.answers.length > 0) {
      data.answers.forEach((a, i) => {
        const div = document.createElement("div");
        div.className = "dassistant-answer";

        // Handle both object and string answer formats.
        if (typeof a === "string") {
          div.innerHTML = `<span class="dassistant-answer-letter">${String.fromCharCode(65 + i)}</span><span class="dassistant-answer-text">${escapeHtml(a)}</span>`;
        } else {
          // Object format: {number, statement, option, explanation, failure_reasons}
          const letter = a.option || String.fromCharCode(65 + i);
          const statement = a.statement ? `<div class="dassistant-answer-statement">${escapeHtml(a.statement)}</div>` : "";
          const explanation = a.explanation ? `<div class="dassistant-answer-explanation">${escapeHtml(a.explanation)}</div>` : "";
          const failures = (a.failure_reasons && a.failure_reasons.length > 0)
            ? `<div class="dassistant-answer-failures">Issues: ${escapeHtml(a.failure_reasons.join(", "))}</div>`
            : "";
          div.innerHTML = `<span class="dassistant-answer-letter">${escapeHtml(String(letter))}</span><span class="dassistant-answer-text">${statement}${explanation}${failures}</span>`;
        }
        answersEl.appendChild(div);
      });
    }

    // Correct option.
    if (data.correct_option !== null && data.correct_option !== undefined) {
      const correctDiv = document.createElement("div");
      correctDiv.className = "dassistant-correct";
      correctDiv.textContent = `Correct Answer: ${data.correct_option}`;
      answersEl.insertBefore(correctDiv, answersEl.firstChild);
    }

    // Detailed answer (GENERAL mode — non-MCQ content).
    if (data.detailed_answer) {
      const detailDiv = document.createElement("div");
      detailDiv.className = "dassistant-explanation";
      detailDiv.style.whiteSpace = "pre-wrap";
      detailDiv.textContent = data.detailed_answer;
      answersEl.appendChild(detailDiv);
    }

    // Explanation.
    if (data.explanation) {
      const expDiv = document.createElement("div");
      expDiv.className = "dassistant-explanation";
      expDiv.textContent = data.explanation;
      answersEl.appendChild(expDiv);
    }

    // Failure reasons.
    if (data.failure_reasons && data.failure_reasons.length > 0) {
      const failDiv = document.createElement("div");
      failDiv.className = "dassistant-fail";
      failDiv.innerHTML = "<strong>Issues:</strong><ul>" +
        data.failure_reasons.map(r => `<li>${escapeHtml(r)}</li>`).join("") + "</ul>";
      answersEl.appendChild(failDiv);
    }

    // Credits — backend sends 'credits_remaining' (not 'remaining_credits').
    // Use != null check so 0 is displayed correctly (0 is falsy but valid).
    if (data.credits_remaining != null) {
      const total = typeof data.credits_remaining === "object"
        ? data.credits_remaining.total
        : data.credits_remaining;
      creditEl.textContent = `${total} left`;
      pillCreditEl.textContent = `${total} left`;
      // Cache locally so the popup shows the updated count instantly.
      try { chrome.storage.local.set({ lastKnownCredits: total }); } catch (e) {}
    }
    if (data.credits_spent) {
      subEl.textContent = `Spent ${data.credits_spent} credit${data.credits_spent > 1 ? "s" : ""} this analysis`;
    }
  }

  function showError(message) {
    expandOverlay();
    overlayEl.classList.remove("dassistant-pill-busy");
    pillTextEl.textContent = "Analyze";
    spinnerEl.style.display = "none";
    overlayEl.querySelector("#dassistant-analyze-btn").disabled = false;
    indicatorEl.textContent = "✗";
    indicatorEl.style.color = "#ef4444";
    headerEl.textContent = "Error";
    subEl.textContent = message || "Something went wrong.";
    answersEl.innerHTML = "";
    badgeEl.innerHTML = "";
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // ---------------------------------------------------------------------------
  // Analysis flow
  // ---------------------------------------------------------------------------

  function triggerAnalyze() {
    // Prevent double-triggering (double-click, etc.) — would charge
    // the user twice.
    if (isAnalyzing) return;
    isAnalyzing = true;

    showLoading("Recording 5s clip...");

    // Hide overlay so it doesn't appear in the recording. The overlay
    // stays hidden during the 5s recording, then is restored to show
    // "Analyzing..." status.
    hiddenForCapture = true;
    overlayEl.style.visibility = "hidden";

    let visibilityRestored = false;
    const restoreVisibility = () => {
      if (visibilityRestored) return;
      visibilityRestored = true;
      if (overlayEl) overlayEl.style.visibility = "visible";
      hiddenForCapture = false;
    };

    // Restore visibility after 5.5s (recording duration + buffer).
    // The background sends RECORDING_STARTED which we handle, but as a
    // fallback this timer ensures the overlay comes back.
    const recordingTimer = setTimeout(() => {
      restoreVisibility();
      showLoading("Analyzing clip...");
    }, 5500);

    // Watchdog: guarantee restoration after 40s no matter what.
    // The extension's fetch timeout is 35s, so 40s gives 5s buffer
    // for the error message to arrive before the watchdog fires.
    const watchdog = setTimeout(() => {
      restoreVisibility();
      isAnalyzing = false;
      clearTimeout(recordingTimer);
      showError("Analysis timed out. Please try again.");
    }, 40000);

    // Progressive status messages — keeps the user informed during
    // long waits (Gemini retries, model fallback, etc.).
    const statusTimers = [
      setTimeout(() => {
        if (spinnerEl.style.display !== "none") {
          headerEl.textContent = "Still analyzing...";
          pillTextEl.textContent = "Working on it...";
        }
      }, 12000),
      setTimeout(() => {
        if (spinnerEl.style.display !== "none") {
          headerEl.textContent = "AI is busy — retrying...";
          pillTextEl.textContent = "Retrying...";
        }
      }, 20000),
    ];

    const clearStatusTimers = () => {
      statusTimers.forEach(t => clearTimeout(t));
    };

    // Send ANALYZE immediately — the background script handles the
    // 5s recording internally and calls Gemini when done. We don't
    // need to wait 5.5s before sending the message.
    try {
      chrome.runtime.sendMessage({ type: "ANALYZE" }, (resp) => {
        clearStatusTimers();
        clearTimeout(recordingTimer);
        clearTimeout(watchdog);
        restoreVisibility();
        isAnalyzing = false;

        if (chrome.runtime.lastError) {
          showError("We lost connection to the extension. Please try again.");
          return;
        }
        if (!resp) {
          showError("Something went wrong. Please try analyzing again.");
          return;
        }
        if (resp.error) {
          if (resp.code === "NO_ACCOUNT") {
            showError("We couldn't verify your account. Click the extension icon to sign in again.");
          } else if (resp.code === "NO_CREDITS") {
            showError("You're out of credits. Visit the website to add more and continue analyzing.");
          } else if (resp.code === "AI_BUSY") {
            showError("Our AI is experiencing high demand right now. Please try again in a moment.");
          } else if (resp.code === "CAPTURE_FAILED") {
            showError("We couldn't capture your screen. Please try again, and make sure you're on a regular web page.");
          } else if (resp.code === "BLOCKED") {
            showError("Your account has been suspended. Please contact support for assistance.");
          } else if (resp.code === "NETWORK_ERROR") {
            showError("We couldn't reach our servers. Please check your internet connection and try again.");
          } else {
            showError(resp.message || "Something went wrong. Please try again in a moment.");
          }
          return;
        }
        showResult(resp);
      });
    } catch (e) {
      clearStatusTimers();
      clearTimeout(recordingTimer);
      clearTimeout(watchdog);
      restoreVisibility();
      isAnalyzing = false;
      showError("Something went wrong. Please try again.");
    }
  }

  // ---------------------------------------------------------------------------
  // Message listener (from background)
  // ---------------------------------------------------------------------------

  // Message listener — guard against double-registration when the
  // extension is reloaded and content.js is injected again.
  // NOTE: We can't use a simple boolean flag because when the extension
  // is reloaded, the old listener dies but the flag survives in the
  // page, causing the new listener to never be registered. Instead,
  // we always register but remove the previous one first.
  if (window.__dassistantListener) {
    try { chrome.runtime.onMessage.removeListener(window.__dassistantListener); } catch (e) {}
  }
  window.__dassistantListener = (msg, sender, sendResponse) => {
    if (msg.type === "SHOW_OVERLAY_TRIGGER") {
      triggerAnalyze();
    } else if (msg.type === "RECORDING_STARTED") {
      // Background is recording a video clip — update the overlay.
      showLoading("Recording 5s clip...");
    } else if (msg.type === "SHOW_OVERLAY_ONLY") {
      // Force-show the overlay pill — used by the popup icon when
      // the overlay disappeared or was closed.
      if (!overlayEl || !document.body.contains(overlayEl)) {
        overlayEl = null;
        createOverlay();
      }
      overlayEl.style.display = "block";
      overlayEl.style.visibility = "visible";
      collapseOverlay();
    } else if (msg.type === "MODE_CHANGED") {
      updateModeDisplay(msg.mode);
    }
    sendResponse({ ok: true });
  };
  chrome.runtime.onMessage.addListener(window.__dassistantListener);

  // ---------------------------------------------------------------------------
  // Resilience: some sites (SPAs like Gmail, X, YouTube, etc.) rewrite or
  // replace document.body, which silently detaches our overlay from the DOM.
  // Watch for that and re-inject automatically so the overlay never
  // "disappears" for the rest of the session.
  // ---------------------------------------------------------------------------

  let currentBody = document.body;
  let bodyObserver = null;

  function ensureOverlayAttached() {
    if (!document.body) return; // XML pages or transient DOM states
    if (!overlayEl || !document.body.contains(overlayEl)) {
      const wasExpanded = overlayEl && overlayEl.classList.contains("dassistant-expanded");
      const wasHidden = overlayEl && overlayEl.style.display === "none";
      overlayEl = null;
      createOverlay();
      if (wasExpanded) {
        overlayEl.classList.remove("dassistant-collapsed");
        overlayEl.classList.add("dassistant-expanded");
      }
      // If it was deliberately hidden (user clicked ×), keep it hidden.
      // Otherwise always show it.
      if (wasHidden) {
        overlayEl.style.display = "none";
      } else {
        overlayEl.style.display = "block";
        overlayEl.style.visibility = "visible";
      }
    }
    // If document.body was swapped out, re-attach the body observer
    // to the new body so future swaps are still caught.
    if (bodyObserver && currentBody !== document.body) {
      currentBody = document.body;
      try { bodyObserver.observe(document.body, { childList: true, subtree: false }); } catch (e) {}
    }
  }

  // Guard against duplicate observers/intervals on re-injection.
  // Same approach as the message listener: remove the old observer
  // before adding a new one. A simple boolean flag would survive
  // extension reload and prevent the new injection from setting up
  // a fresh observer (the old one references dead variables).
  if (window.__dassistantObserver) {
    try { window.__dassistantObserver.disconnect(); } catch (e) {}
  }
  if (window.__dassistantInterval) {
    try { clearInterval(window.__dassistantInterval); } catch (e) {}
  }
  bodyObserver = new MutationObserver(() => {
    ensureOverlayAttached();
  });
  window.__dassistantObserver = bodyObserver;
  try { bodyObserver.observe(document.body, { childList: true, subtree: false }); } catch (e) {}
  // Also watch <html> in case the whole <body> element gets replaced
  // (some SPA frameworks do a full body swap on route change).
  try { bodyObserver.observe(document.documentElement, { childList: true, subtree: false }); } catch (e) {}

  // Belt-and-suspenders: some SPA re-renders don't fire an observable
  // mutation in time (e.g. the observer's own target node was itself
  // replaced). A lightweight periodic check catches those edge cases.
  window.__dassistantInterval = setInterval(ensureOverlayAttached, 3000);

  // Show overlay (collapsed pill) on page load — ALWAYS.
  // The overlay shows on every page automatically. The close (×) button
  // only hides it on the current page, not globally. The popup's show
  // icon brings it back.
  createOverlay();

})(); // End IIFE
