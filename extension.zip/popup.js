// popup.js — email-based popup for dassistant

const BACKEND_URL = "https://godsfavor.onrender.com";

const signinSection = document.getElementById("signin-section");
const accountSection = document.getElementById("account-section");
const loadingSection = document.getElementById("loading-section");
const emailInput = document.getElementById("emailInput");
const signinBtn = document.getElementById("signinBtn");
const emailDisplay = document.getElementById("emailDisplay");
const creditsNum = document.getElementById("creditsNum");
const signoutBtn = document.getElementById("signoutBtn");
const statusMsg = document.getElementById("statusMsg");

let currentEmail = null;

async function refreshCredits() {
  if (!currentEmail) return;
  try {
    const r = await fetch(`${BACKEND_URL}/credits/balance`, {
      headers: { "X-User-Email": currentEmail },
    });
    if (r.ok) {
      const data = await r.json();
      const total = data.total || 0;
      creditsNum.textContent = total;
      // Cache so next popup open shows instantly.
      chrome.storage.local.set({ lastKnownCredits: total });
    }
  } catch (e) { /* keep showing last known value */ }
}

function showStatus(msg, type) {
  statusMsg.className = "status " + (type || "info");
  statusMsg.textContent = msg;
  setTimeout(() => { statusMsg.textContent = ""; statusMsg.className = ""; }, 4000);
}

// Load current status on popup open.
async function loadPopupState() {
  const stored = await chrome.storage.local.get(["email", "lastKnownCredits"]);
  const email = stored.email || null;
  const cachedCredits = stored.lastKnownCredits != null ? stored.lastKnownCredits : "...";

  if (email) {
    // Already logged in — show account view immediately.
    loadingSection.style.display = "none";
    signinSection.style.display = "none";
    accountSection.style.display = "block";
    emailDisplay.textContent = email;
    currentEmail = email;
    creditsNum.textContent = cachedCredits;

    // Sync the real balance in background.
    refreshCredits();
  } else {
    // Not signed in.
    loadingSection.style.display = "none";
    signinSection.style.display = "block";
    accountSection.style.display = "none";
  }
}

loadPopupState();

function isValidEmail(email) {
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email);
}

signinBtn.addEventListener("click", () => {
  const email = emailInput.value.trim().toLowerCase();
  if (!email || !isValidEmail(email)) {
    showStatus("Please enter a valid email address (e.g. you@example.com).", "err");
    return;
  }

  // Instantly store the email locally and show the account view.
  chrome.storage.local.set({
    email: email,
  }, () => {
    // Switch to account view immediately.
    loadingSection.style.display = "none";
    signinSection.style.display = "none";
    accountSection.style.display = "block";
    emailDisplay.textContent = email;
    currentEmail = email;
    creditsNum.textContent = "...";

    // Show the overlay on the current tab immediately.
    chrome.runtime.sendMessage({ type: "SHOW_OVERLAY_ON_TAB" });

    // Now register/login in the background. The backend returns the
    // real credit balance (4 for new users, actual balance for
    // returning users).
    chrome.runtime.sendMessage({ type: "LOGIN_EMAIL", email }, (resp) => {
      if (chrome.runtime.lastError) {
        return;
      }
      if (resp && resp.credits) {
        const total = resp.credits.total != null ? resp.credits.total : resp.credits;
        creditsNum.textContent = total;
        chrome.storage.local.set({ lastKnownCredits: total });
      }
      refreshCredits();
    });
  });
});

// Allow pressing Enter in the email field to sign in.
emailInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    signinBtn.click();
  }
});

// Sign out — clears all stored account data.
signoutBtn.addEventListener("click", () => {
  currentEmail = null;
  chrome.storage.local.remove(["email", "lastKnownCredits"], () => {
    window.location.reload();
  });
});

// ---------------------------------------------------------------------------
// Visit website button
// ---------------------------------------------------------------------------

const visitWebsiteBtn = document.getElementById("visitWebsiteBtn");
if (visitWebsiteBtn) {
  visitWebsiteBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://dassistant.netlify.app/" });
  });
}

// ---------------------------------------------------------------------------
// Show overlay button
// ---------------------------------------------------------------------------

const showOverlayBtn = document.getElementById("showOverlayBtn");
if (showOverlayBtn) {
  showOverlayBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "SHOW_OVERLAY_ON_TAB" });
    window.close();
  });
}
