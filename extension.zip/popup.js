// popup.js — email-based popup for dassistant

const BACKEND_URL = "https://godsfavor.onrender.com";

const signinSection = document.getElementById("signin-section");
const accountSection = document.getElementById("account-section");
const loadingSection = document.getElementById("loading-section");
const emailInput = document.getElementById("emailInput");
const signinBtn = document.getElementById("signinBtn");
const emailDisplay = document.getElementById("emailDisplay");
const creditsNum = document.getElementById("creditsNum");
const signoutBtn = document.getElementById("signoutBtn");
const statusMsg = document.getElementById("statusMsg");

let currentLicenseKey = null;

async function refreshCredits() {
  if (!currentLicenseKey) return;
  try {
    const r = await fetch(`${BACKEND_URL}/credits/balance`, {
      headers: { "X-License-Key": currentLicenseKey },
    });
    if (r.ok) {
      const data = await r.json();
      const total = data.total || 0;
      creditsNum.textContent = total;
      // Cache so next popup open shows instantly.
      chrome.storage.local.set({ lastKnownCredits: total });
    }
  } catch (e) { /* keep showing last known value */ }
}

function showStatus(msg, type) {
  statusMsg.className = "status " + (type || "info");
  statusMsg.textContent = msg;
  setTimeout(() => { statusMsg.textContent = ""; statusMsg.className = ""; }, 4000);
}

// Load current status on popup open.
// We check chrome.storage.local DIRECTLY first (instant, no service
// worker needed), then fall back to GET_STATUS for the license key.
// This ensures the popup always shows the right view even if the
// service worker is asleep or cold-starting.
async function loadPopupState() {
  // Check storage directly — this is instant and doesn't depend on
  // the service worker being awake.
  const stored = await chrome.storage.local.get(["email", "licenseKey", "lastKnownCredits"]);
  const email = stored.email || null;
  const licenseKey = stored.licenseKey || null;
  const cachedCredits = stored.lastKnownCredits != null ? stored.lastKnownCredits : 15;

  if (email) {
    // Already logged in — show account view immediately.
    loadingSection.style.display = "none";
    signinSection.style.display = "none";
    accountSection.style.display = "block";
    emailDisplay.textContent = email;
    currentLicenseKey = licenseKey;
    creditsNum.textContent = cachedCredits;

    // If we have a license key, sync the real balance in background.
    if (currentLicenseKey) {
      refreshCredits();
    } else {
      // No license key yet — try to register in background.
      chrome.runtime.sendMessage({ type: "LOGIN_EMAIL", email }, (r) => {
        if (r && r.licenseKey) {
          currentLicenseKey = r.licenseKey;
          if (r.credits) {
            const total = r.credits.total || r.credits;
            creditsNum.textContent = total;
            chrome.storage.local.set({ lastKnownCredits: total });
          }
          refreshCredits();
        }
      });
    }
  } else {
    // Not signed in.
    loadingSection.style.display = "none";
    signinSection.style.display = "block";
    accountSection.style.display = "none";
  }
}

loadPopupState();

// Enter email — instantly shows account view. Backend registration
// happens in the background. The email is just an identity marker; we
// don't block the UI waiting for the server.
function isValidEmail(email) {
  // RFC-style check: must have local@domain.tld with at least 2-char TLD.
  // Rejects "abc@", "abc@def", "abc@.com", "abc@def.", etc.
  const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return re.test(email);
}

signinBtn.addEventListener("click", () => {
  const email = emailInput.value.trim().toLowerCase();
  if (!email || !isValidEmail(email)) {
    showStatus("Please enter a valid email address (e.g. you@example.com).", "err");
    return;
  }

  // Instantly store the email locally and show the account view.
  // Don't hardcode 15 credits — the user might be returning with a
  // different balance. Show "..." until the backend responds.
  chrome.storage.local.set({
    email: email,
  }, () => {
    // Switch to account view immediately.
    loadingSection.style.display = "none";
    signinSection.style.display = "none";
    accountSection.style.display = "block";
    emailDisplay.textContent = email;
    creditsNum.textContent = "...";

    // Show the overlay on the current tab immediately so the user
    // sees the analyze pill without having to open a new tab.
    chrome.runtime.sendMessage({ type: "SHOW_OVERLAY_ON_TAB" });

    // Now register/login in the background. The backend returns the
    // real credit balance (15 for new users, actual balance for
    // returning users).
    chrome.runtime.sendMessage({ type: "LOGIN_EMAIL", email }, (resp) => {
      if (chrome.runtime.lastError) {
        // Backend might be cold-starting. Show 15 as a fallback for
        // new users — the backend will sync on next analysis.
        creditsNum.textContent = 15;
        chrome.storage.local.set({ lastKnownCredits: 15 });
        return;
      }
      if (resp && resp.licenseKey) {
        currentLicenseKey = resp.licenseKey;
        // Update credits from server — this is the real balance.
        if (resp.credits) {
          const total = resp.credits.total || resp.credits;
          creditsNum.textContent = total;
          chrome.storage.local.set({ lastKnownCredits: total });
        } else {
          // New user with no credits field — default to 15 trial credits.
          creditsNum.textContent = 15;
          chrome.storage.local.set({ lastKnownCredits: 15 });
        }
        refreshCredits(); // sync exact balance in background
      } else if (resp && resp.error) {
        // Backend returned an error — show it.
        creditsNum.textContent = 15;
        chrome.storage.local.set({ lastKnownCredits: 15 });
      }
    });
  });
});

// Allow pressing Enter in the email field to sign in.
emailInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") {
    signinBtn.click();
  }
});

// Sign out — clears all stored account data so the next user starts fresh.
signoutBtn.addEventListener("click", () => {
  currentLicenseKey = null;
  chrome.storage.local.remove(["email", "licenseKey", "lastKnownCredits"], () => {
    window.location.reload();
  });
});

// ---------------------------------------------------------------------------
// Visit website button — directs user to payment page
// ---------------------------------------------------------------------------

const visitWebsiteBtn = document.getElementById("visitWebsiteBtn");
if (visitWebsiteBtn) {
  visitWebsiteBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: "https://dassistant.netlify.app/" });
  });
}

// ---------------------------------------------------------------------------
// Show overlay button — forces the overlay to appear on the current tab.
// Useful if the overlay disappeared or was closed.
// ---------------------------------------------------------------------------

const showOverlayBtn = document.getElementById("showOverlayBtn");
if (showOverlayBtn) {
  showOverlayBtn.addEventListener("click", () => {
    // Send the request to the background service worker, which stays
    // alive after the popup closes. The background handles injecting
    // the content script and showing the overlay.
    chrome.runtime.sendMessage({ type: "SHOW_OVERLAY_ON_TAB" });
    // Close the popup immediately.
    window.close();
  });
}
