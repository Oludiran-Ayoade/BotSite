// offscreen.js — Records a short video clip from a tab capture stream.
//
// In MV3, the service worker can't access DOM/video APIs. We use an
// offscreen document to play the MediaStream from chrome.tabCapture
// and record it with MediaRecorder.

let mediaRecorder = null;
let chunks = [];
let stream = null;
let videoEl = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "START_RECORDING") {
    startRecording(msg.streamId, msg.durationMs || 5000)
      .then((blob) => sendResponse({ success: true, mimeType: blob.type, size: blob.size }))
      .catch((err) => sendResponse({ success: false, error: String(err) }));
    return true; // keep channel open for async response
  }

  if (msg.type === "GET_RECORDED_DATA") {
    sendResponse({ success: true, chunks: chunks, mimeType: mediaRecorder ? mediaRecorder.mimeType : "video/webm" });
    return false;
  }

  if (msg.type === "GET_RECORDED_BASE64") {
    // Convert recorded chunks to a single base64 string.
    if (!chunks || chunks.length === 0) {
      sendResponse({ success: false, error: "No data recorded" });
      return false;
    }
    const blob = new Blob(chunks, { type: mediaRecorder ? mediaRecorder.mimeType : "video/webm" });
    const reader = new FileReader();
    reader.onloadend = () => {
      // reader.result is a data URL: "data:video/webm;base64,AAAA..."
      const dataUrl = reader.result;
      const base64 = dataUrl.split(",")[1];
      sendResponse({ success: true, base64: base64, mimeType: blob.type });
    };
    reader.onerror = () => sendResponse({ success: false, error: "FileReader error" });
    reader.readAsDataURL(blob);
    return true; // async
  }

  if (msg.type === "STOP_RECORDING") {
    if (mediaRecorder && mediaRecorder.state !== "inactive") {
      mediaRecorder.stop();
    }
    sendResponse({ success: true });
    return false;
  }
});

async function startRecording(streamId, durationMs) {
  // Get the tab capture stream using the streamId from background.
  stream = navigator.mediaDevices.getUserMedia({
    audio: false,
    video: {
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId,
      },
    },
  });

  // Wait for the stream.
  const resolvedStream = await stream;

  // Create a video element to "play" the stream (required for capture).
  videoEl = document.createElement("video");
  videoEl.srcObject = resolvedStream;
  videoEl.play().catch(() => {}); // Ignore play errors — recording works regardless

  // Set up MediaRecorder with a low bitrate to keep the file size
  // small. A 5s clip at 1Mbps = ~625KB, which base64-encodes to
  // ~830KB — well within HTTP body limits. Without this, the default
  // bitrate could produce files several MB large, causing slow uploads
  // and backend timeouts.
  chunks = [];
  const options = { mimeType: "video/webm;codecs=vp9", videoBitsPerSecond: 1000000 };
  try {
    mediaRecorder = new MediaRecorder(resolvedStream, options);
  } catch (e) {
    // Fallback to default codec.
    try {
      mediaRecorder = new MediaRecorder(resolvedStream, { videoBitsPerSecond: 1000000 });
    } catch (e2) {
      try {
        mediaRecorder = new MediaRecorder(resolvedStream);
      } catch (e3) {
        throw new Error("MediaRecorder not supported in this browser");
      }
    }
  }

  mediaRecorder.ondataavailable = (e) => {
    if (e.data && e.data.size > 0) {
      chunks.push(e.data);
    }
  };

  return new Promise((resolve, reject) => {
    mediaRecorder.onstop = () => {
      // Stop all tracks.
      resolvedStream.getTracks().forEach((t) => t.stop());
      const blob = new Blob(chunks, { type: mediaRecorder.mimeType || "video/webm" });
      resolve(blob);
    };

    mediaRecorder.onerror = (e) => reject(e.error || new Error("Recording error"));

    mediaRecorder.start();

    // Stop after the specified duration.
    setTimeout(() => {
      if (mediaRecorder && mediaRecorder.state !== "inactive") {
        mediaRecorder.stop();
      }
    }, durationMs);
  });
}
